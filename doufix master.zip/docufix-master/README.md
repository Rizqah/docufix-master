# docufix
HNG i6

This is an app that compares document content and find out the differences contained in each of the files 

It shows you the compared data result in percentage %

You can choose to download compared documents as .doc file if you wish

Compared texts are editable, this means you can edit your work for correction after comparing.
